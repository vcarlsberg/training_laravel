<?php
//print_r($todos);
?>

<table border="1">
<tr>
<td>Title</td>
<td>Description</td>
<td>Category</td>
</tr>

<?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
    <td><?php echo e($todo->title); ?></td>
    <td><?php echo e($todo->description); ?></td>
    <td><?php echo e($todo->category->name); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

