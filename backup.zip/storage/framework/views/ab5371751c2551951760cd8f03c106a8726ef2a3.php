<?php $__env->startSection('title','Form todo'); ?>
<?php $__env->startSection('content'); ?>
<div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Bordered Table</h3>
        </div>
        <div class="box-body">

<?php echo $__env->make('share.user_validation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php echo e(Form::open(['url'=>'user','class'=>'form-horizontal'])); ?>


<?php echo $__env->make('user.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="form-group">
            <label class="col-sm-2 control-label"></label>
            <div class="col-sm-10">
                    <?php echo e(Form::submit('Save User',['class'=>'btn btn-success'])); ?>

                    <?php echo e(link_to('/user','Back',['class'=>'btn btn-info'])); ?>


            </div>
    </div>  
    
    

    <?php echo e(Form::close()); ?>

        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>