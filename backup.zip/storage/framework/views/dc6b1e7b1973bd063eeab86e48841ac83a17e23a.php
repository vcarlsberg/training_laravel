<?php $__env->startSection('title','List User'); ?>
<?php $__env->startSection('content'); ?>
<div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Bordered Table</h3>
        </div>
        <div class="box-body">
        <?php echo e(Session ('message')); ?>

            <table id="users-table" class="table table-bordered">
                <tr>
                <thead>
                    <!-- <th></th> -->
                    <th>Nama</th>
                    <th>Email</th>
                    <!-- <th>Password</th> -->
                    <!-- <th>Edit</th>
                    <th>Delete</th> -->
                </tr>
                </thead>
                <!-- <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->password); ?></td>
                        <th><?php echo e(link_to('user/'.$user->id.'/edit','Edit',['class'=>'btn btn-info'])); ?></th>
                        <th>
                        <?php echo e(Form::open(['url'=>'user/'.$user->id,'method'=>'delete','style'=>'float:right','onClick'=>"return confirm('Apakah anda yakin akan menghapus data ini?');"])); ?>

                        <?php echo e(Form::submit('delete',['class'=>'btn btn-success'])); ?>

                        <?php echo e(Form::close()); ?>

                        </th>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
            </table>
            <hr>
            <?php echo e($users->links()); ?>

            <a href="/user/create" class="btn btn-danger btn-sm">Create New User</a>
        </div>
</div>



    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function() {
    $('#users-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: '/user/json',
        columns: [
            { data: 'name', name: 'name' },
            { data: 'email', name: 'email' },
            // { data: 'password', name: 'password' }
        ]
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>