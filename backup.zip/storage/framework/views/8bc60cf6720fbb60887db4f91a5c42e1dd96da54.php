<?php $__env->startSection('title','List Todo'); ?>
<?php $__env->startSection('content'); ?>
<div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Bordered Table</h3>
        </div>
        <div class="box-body">
        <?php echo e(Session ('message')); ?>

            <table id="users-table" class="table table-bordered">
            
                <tr>
                <thead>
                    <th></th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Created at</th>
                    <th width="150"></th>
                    <th></th>
                </thead>
                </tr>
                
                <!-- <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($todo->title); ?></td>
                        <td><?php echo e($todo->description); ?></td>
                        <td><?php echo e($todo->created_at); ?></td>
                        <td>
                        <?php echo e(link_to('todo/'.$todo->id.'/edit','Edit',['class'=>'btn btn-info'])); ?>

                        <?php echo e(Form::open(['url'=>'todo/'.$todo->id,'method'=>'delete','style'=>'float:right','onClick'=>"return confirm('Apakah anda yakin akan menghapus data ini?');"])); ?>

                        <?php echo e(Form::submit('delete',['class'=>'btn btn-success'])); ?>

                        <?php echo e(Form::close()); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
            </table>
            <hr>
            <!-- <?php echo e($todos->links()); ?> -->
            <a href="/todo/create" class="btn btn-danger btn-sm">Create New Todo</a>
        </div>
        
</div>



    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function() {
    $('#users-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: '/todo/json',
        columns: [
            { data: 'images', name: 'images' },
            { data: 'title', name: 'title' },
            { data: 'description', name: 'description' },
            { data: 'created_at', name: 'created_at' },
            { data: 'updated_at', name: 'updated_at' },
            { data: 'action', name: 'action' }
        ]
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>