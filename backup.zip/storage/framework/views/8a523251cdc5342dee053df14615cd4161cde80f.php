<?php $__env->startSection('title','Form todo'); ?>
<?php $__env->startSection('content'); ?>
    <h2>Form Todo</h2>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <?php echo e(Form::open(['url'=>'todo'])); ?>

    <?php echo e(Form::text('title',null,['placeholder'=>'Todo Title'])); ?>

    <br>
    <?php echo e(Form::select('category',[1=>'Urgent',2=>'Normal',3=>'Slow'],null)); ?>

    <br>
    <?php echo e(Form::textarea('description',null)); ?>

        <br>
    <?php echo e(Form::submit('Save Todo')); ?>

    <?php echo e(link_to('/todo','Back')); ?>

    <?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>