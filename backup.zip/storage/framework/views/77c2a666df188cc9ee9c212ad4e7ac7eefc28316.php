<?php echo e(Form::text('title',null,['placeholder'=>'Todo Title'])); ?>

<br>
<?php echo e(Form::select('category',$categories,null)); ?>

<br>
<?php echo e(Form::textarea('description',null)); ?>

<br>
<?php echo e(Form::file('images')); ?>