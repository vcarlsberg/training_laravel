<?php $__env->startSection('title','Form todo'); ?>
<?php $__env->startSection('content'); ?>
    <h2>Form Todo</h2>

    <?php echo $__env->make('share.validation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo e(Form::open(['url'=>'todo','files'=>'true'])); ?>

    <?php echo $__env->make('todo.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo e(Form::submit('Save Todo')); ?>

    <?php echo e(link_to('/todo','Back')); ?>

    <?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>